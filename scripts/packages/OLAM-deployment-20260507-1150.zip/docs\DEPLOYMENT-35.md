# Deployment a 172.18.164.35 — Guía Operativa

## Problema

El servidor 172.18.164.35 (Win10 cliente) **no tiene acceso a internet**, por lo que:
- ❌ `git pull origin main` falla con "Could not resolve host: github.com"
- ❌ No se pueden descargar dependencias npm desde internet en tiempo de deployment
- ✅ **Se puede usar RDP folder redirection** para compartir archivos locales

## Solución

Usar un flujo **zip-based** que no requiere internet:
1. En tu laptop: empaquetar código + node_modules precompilados
2. Compartir vía RDP file manager
3. En .35: extraer y reiniciar

---

## Flujo de Deployment (paso a paso)

### Paso 1: Commit y Push a main (en tu laptop)

```bash
cd ~/projects/OLAM
git status                    # Verificar cambios listos
git commit -m "..."          # Si hay cambios
git push origin main         # Confirmar en GitHub
```

**Importante:** Los scripts de deployment verifican que estés en rama `main` con todo commiteado.

### Paso 2: Crear paquete de deployment (en tu laptop)

```powershell
cd C:\Users\Maximiliano Pulido\OLAM
powershell -ExecutionPolicy Bypass -File .\scripts\create-deployment-package.ps1
```

**Qué hace:**
- ✓ Verifica que estés en rama `main` y todo esté commiteado
- ✓ Crea un zip con backend + frontend + scripts + docs
- ✓ **Excluye** node_modules (se instalarán en .35)
- ✓ Genera nombre de archivo: `OLAM-deployment-YYYYMMDD-HHMM.zip`
- ✓ Guarda en: `scripts/packages/`

**Output esperado:**
```
========================================
OLAM — Crear Paquete de Deployment
========================================

[1/3] Verificar estado git...
  ✓ Rama: main
  ✓ Última actualización: abc1234 feat(dashboard): ...

[2/3] Empaquetar código...
  ✓ Empaquetado: OLAM-deployment-20260507-1430.zip
  Tamaño: 4.52 MB

[3/3] Instrucciones para desplegar a 172.18.164.35
...
```

### Paso 3: Copiar zip a 172.18.164.35 vía RDP (en tu laptop)

1. **Abre RDP** a 172.18.164.35 (si no está abierto)
   ```
   mstsc /v:172.18.164.35
   ```

2. **En la conexión RDP, abre File Manager** en .35

3. **En la barra de direcciones, navega a tu laptop:**
   ```
   \\tsclient\C\Users\Maximiliano Pulido\OLAM\scripts\packages\
   ```
   Este es el folder compartido de tu laptop via RDP redirection.

4. **Copia el último zip** (ej: `OLAM-deployment-20260507-1430.zip`)

5. **Pégalo en .35** en una carpeta accesible, ej:
   ```
   C:\temp\OLAM-deployment-20260507-1430.zip
   ```

### Paso 4: Ejecutar deployment en .35 (en RDP)

En una **PowerShell en .35**, ejecuta:

```powershell
powershell -ExecutionPolicy Bypass -File "C:\olam\scripts\deploy-from-zip.ps1" -ZipFile "C:\temp\OLAM-deployment-20260507-1430.zip"
```

**Qué hace:**
- ✓ Extrae el zip
- ✓ Actualiza código en `C:\olam\backend` y `C:\olam\frontend`
- ✓ Elimina `node_modules` viejos
- ✓ Ejecuta `npm install --omit=dev` en backend y frontend
- ✓ Mata procesos `node` anteriores
- ✓ Limpia archivos temporales

**Output esperado:**
```
========================================
OLAM — Desplegar desde Zip
========================================

[1/5] Preparar...
  Zip file: C:\temp\OLAM-deployment-20260507-1430.zip
  Destino: C:\olam

[2/5] Extraer zip...
  ✓ Extraído a: C:\olam\.deploy-temp

[3/5] Actualizar código...
  Backend...
    ✓ Backend actualizado
  Frontend...
    ✓ Frontend actualizado
  Docs y scripts...
    ✓ OK

[4/5] npm install...
  Backend...
    ✓ OK
  Frontend...
    ✓ OK

[5/5] Reiniciar servicios...
  Matando procesos node...
    ✓ OK
  Limpieza...
    ✓ OK

========================================
✓ DEPLOYMENT COMPLETADO
========================================

Próximos pasos:

Terminal 1 — Backend (puerto 3000):
  cd C:\olam\backend
  npm run dev

Terminal 2 — Frontend (puerto 5173):
  cd C:\olam\frontend
  npm run dev

Dashboard: http://localhost:5173
```

### Paso 5: Reiniciar servicios (en .35)

En dos terminales PowerShell en .35:

**Terminal 1 — Backend:**
```powershell
cd C:\olam\backend
npm run dev
```

**Terminal 2 — Frontend:**
```powershell
cd C:\olam\frontend
npm run dev
```

Luego accede a: **http://localhost:5173** en el navegador de .35.

---

## Troubleshooting

### El zip no se ve en RDP
**Problema:** El folder `\\tsclient\C\...` no aparece en RDP.

**Solución:**
1. Cierra RDP
2. Vuelve a abrirla con local drive redirection:
   ```
   mstsc /v:172.18.164.35 /drives
   ```
3. O abre RDP manualmente y en "Local Resources" marca "Drives" antes de conectar

### npm install falla en .35
**Problema:** El script de deploy dice "npm install: command not found"

**Solución:**
- Verifica que Node.js esté instalado en .35:
  ```powershell
  node --version
  npm --version
  ```
- Si no, instala Node.js 20 LTS desde https://nodejs.org/

### El zip no descomprime
**Problema:** Expand-Archive dice "Cannot find path"

**Solución:**
- Verifica que el archivo existe:
  ```powershell
  Test-Path "C:\temp\OLAM-deployment-20260507-1430.zip"
  ```
- Prueba descomprimir manualmente:
  ```powershell
  cd C:\temp
  Expand-Archive -Path "OLAM-deployment-20260507-1430.zip" -DestinationPath "OLAM-extracted"
  ```

### Procesos node no se cierran
**Problema:** El script dice "Process node not found"

**Solución:** Es normal si no hay procesos node corriendo. El script continúa.

### Backend/Frontend no arrancan después del deploy
**Problema:** `npm run dev` dice "npm: command not found" o similar

**Solución:**
1. Verifica que las dependencias se instalaron:
   ```powershell
   cd C:\olam\backend
   dir node_modules | wc -l    # Debería listar muchas carpetas
   ```
2. Si está vacío, instala manualmente:
   ```powershell
   cd C:\olam\backend
   npm install --omit=dev
   ```

---

## Checklist Pre-Deployment

Antes de crear el paquete, verifica:

- ✅ Estás en rama `main` local
- ✅ Todos los cambios están commiteados (`git status` limpio)
- ✅ Cambios están pusheados a GitHub (`git log -1` debe mostrar el último commit)
- ✅ Código compila localmente (`npm run dev` funciona en tu laptop)
- ✅ Tests pasan (si existen)
- ✅ RDP a 172.18.164.35 está conectado y folder redirection activo

---

## Preguntas Frecuentes

**P: ¿Cómo sé qué versión de código está corriendo en .35?**

A: Cuando arranca el backend, muestra en los logs el último commit. También puedes revisar el archivo más reciente en `C:\olam\docs\HANDOFF-*.md` para saber qué se deployó.

**P: ¿Puedo desplegar sin crear un zip (ej: usando git)?**

A: No, .35 no tiene internet. El zip es el único método soportado sin acceso a GitHub.

**P: ¿Qué pasa si alguien edita código EN .35? ¿Se pierde al desplegar?**

A: Sí, se sobrescribe. El deployment asume que .35 es un cliente **sin historial de cambios**. Ediciones locales se pierden. Siempre commitea en tu laptop, luego despliega.

**P: ¿El zip incluye `.env`?**

A: No, el `.env` se excluye del zip (no queremos exponer credenciales). Después de deployar, verifica que `C:\olam\backend\.env` exista y tenga las credenciales correctas (SSH_HOST, etc.).

**P: ¿Puedo desplegar parcialmente (solo backend o solo frontend)?**

A: El script actual no lo soporta. Se pueden editar los scripts para lograrlo, pero no es necesario en este milestone. Siempre despliega ambos para mantener sync.

---

## Historial de Deployments

Para auditar qué se deployó cuándo, mantén un registro:

| Fecha | Zip | Commit | Cambios | Quién |
|-------|-----|--------|---------|-------|
| 2026-05-07 | OLAM-deployment-20260507-1430.zip | f8711b9 | Validación SC256, UAS dormant, slider 256 | Max |

---

## Siguiente Mejora Potencial

Para futuras sesiones, considerar:
- Script que automáticamente cree y copie el zip sin pasos manuales
- Webhook o monitoring que detecte nuevos commits en GitHub y cree zips automáticamente
- Copiar `.env` + credenciales de forma segura (tal vez encrypted en el zip)

Pero por ahora, este flujo manual es suficiente y auditable.

---

Creado: 2026-05-07  
Versión: 1.0  
Autor: Claude Code (seguimiento de deployment)
