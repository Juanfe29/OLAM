# OLAM Deployment — Quick Reference

## Desplegar código nuevo a 172.18.164.35 (3 pasos)

### Paso 1️⃣ En tu laptop (con código commiteado)

```powershell
cd C:\Users\Maximiliano Pulido\OLAM
powershell -ExecutionPolicy Bypass -File .\scripts\create-deployment-package.ps1
```

**Output:** Crea archivo `scripts/packages/OLAM-deployment-YYYYMMDD-HHMM.zip`

---

### Paso 2️⃣ Copiar zip a 172.18.164.35 vía RDP

1. Abre File Manager en RDP (a 172.18.164.35)
2. Navega a: `\\tsclient\C\Users\Maximiliano Pulido\OLAM\scripts\packages\`
3. Copia el zip más nuevo
4. Pégalo en .35, ej: `C:\temp\`

---

### Paso 3️⃣ Desplegar en .35 (PowerShell)

```powershell
powershell -ExecutionPolicy Bypass -File "C:\olam\scripts\deploy-from-zip.ps1" -ZipFile "C:\temp\OLAM-deployment-YYYYMMDD-HHMM.zip"
```

**Output:** "✓ DEPLOYMENT COMPLETADO" → arranca servicios en dos terminales

---

## Arrancar servicios después (2 terminales en .35)

**Terminal 1:**
```powershell
cd C:\olam\backend
npm run dev
```

**Terminal 2:**
```powershell
cd C:\olam\frontend
npm run dev
```

Dashboard: **http://localhost:5173**

---

## ⚠️ Requisitos

- ✅ Cambios están commiteados en main local (`git status` limpio)
- ✅ RDP folder redirection activo (`mstsc /v:172.18.164.35 /drives`)
- ✅ Node.js 20 LTS instalado en .35

---

## 🔍 Validar deployment

```powershell
# En .35, verifica que nuevos cambios estén ahí
Get-Item "C:\olam\backend\package.json" -Force

# Verifica que npm install pasó
dir "C:\olam\backend\node_modules" | wc -l  # Debería listar ~300+ carpetas
```

---

Para detalles completos, ver: **docs/DEPLOYMENT-35.md**

Creado: 2026-05-07
