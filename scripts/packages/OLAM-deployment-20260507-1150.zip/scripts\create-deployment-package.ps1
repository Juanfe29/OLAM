# OLAM — Crear paquete de deployment
# Ejecutar en tu laptop (con código actualizado y commiteado)
# Resultado: OLAM-deployment-YYYYMMDD-HHMM.zip en scripts/packages/

$ErrorActionPreference = "Stop"

$projectRoot = Split-Path -Parent $PSScriptRoot
$packageDir = "$PSScriptRoot\packages"
$timestamp = Get-Date -Format "yyyyMMdd-HHmm"
$zipName = "OLAM-deployment-$timestamp.zip"
$zipPath = "$packageDir\$zipName"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "OLAM — Crear Paquete de Deployment" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Crear directorio de packages si no existe
if (-not (Test-Path $packageDir)) {
  New-Item -ItemType Directory -Path $packageDir -Force | Out-Null
  Write-Host "  Creado: $packageDir" -ForegroundColor Green
}

# Verificar que estamos en git main y todo está commiteado
Write-Host "[1/3] Verificar estado git..." -ForegroundColor Yellow
cd $projectRoot

$branch = git branch --show-current
if ($branch -ne "main") {
  throw "ERROR: No estás en rama 'main' (estás en '$branch'). Cambia antes de desplegar."
}

$status = git status --porcelain
if ($status) {
  throw "ERROR: Hay cambios sin committear. Haz commit antes de crear el paquete."
}

$lastCommit = git log --oneline -1
Write-Host "  ✓ Rama: main" -ForegroundColor Green
Write-Host "  ✓ Última actualización: $lastCommit" -ForegroundColor Green
Write-Host ""

# Crear zip excluyendo node_modules, .git, etc.
Write-Host "[2/3] Empaquetar código..." -ForegroundColor Yellow

$excludePatterns = @(
  "node_modules",
  ".git",
  ".env",
  "data/",
  ".claude/",
  "*.db",
  "*.log"
)

# Comprimir manualmente usando Compress-Archive
$itemsToZip = @(
  "$projectRoot\backend",
  "$projectRoot\frontend",
  "$projectRoot\scripts",
  "$projectRoot\docs",
  "$projectRoot\CLAUDE.md",
  "$projectRoot\README.md"
)

# Agregar sipp-scenarios si existe
if (Test-Path "$projectRoot\sipp-scenarios") {
  $itemsToZip += "$projectRoot\sipp-scenarios"
}

# Primero comprimimos todo
Compress-Archive -Path $itemsToZip -DestinationPath $zipPath -Force

Write-Host "  ✓ Empaquetado: $zipName" -ForegroundColor Green
$size = (Get-Item $zipPath).Length / 1MB
Write-Host "  Tamaño: $([Math]::Round($size, 2)) MB" -ForegroundColor Cyan
Write-Host ""

# Mostrar instrucciones para copiar a .35
Write-Host "[3/3] Instrucciones para desplegar a 172.18.164.35" -ForegroundColor Yellow
Write-Host ""
Write-Host "1. En RDP, abre el File Manager en .35" -ForegroundColor Gray
Write-Host ""
Write-Host "2. Navega a: \\tsclient\C\Users\Maximiliano Pulido\OLAM\scripts\packages\" -ForegroundColor Cyan
Write-Host ""
Write-Host "3. Copia el archivo $zipName a una carpeta en .35" -ForegroundColor Cyan
Write-Host "   (ej: C:\temp\$zipName)" -ForegroundColor Gray
Write-Host ""
Write-Host "4. En PowerShell en .35, ejecuta:" -ForegroundColor Cyan
Write-Host ""
Write-Host "   powershell -ExecutionPolicy Bypass -File C:\olam\scripts\deploy-from-zip.ps1 -ZipFile 'C:\temp\$zipName'" -ForegroundColor Cyan
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "✓ Paquete listo: $zipPath" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
