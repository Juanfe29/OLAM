# OLAM — Desplegar desde Zip
# Ejecutar en 172.18.164.35 con un archivo zip
# Ejecutar como: powershell -ExecutionPolicy Bypass -File deploy-from-zip.ps1 -ZipFile 'C:\path\to\OLAM-deployment-YYYYMMDD-HHMM.zip'

param(
  [Parameter(Mandatory=$true)]
  [string]$ZipFile
)

$ErrorActionPreference = "Stop"

# Definir rutas en .35
$olamRoot = "C:\olam"
$backendPath = "$olamRoot\backend"
$frontendPath = "$olamRoot\frontend"
$tempExtract = "$olamRoot\.deploy-temp"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "OLAM — Desplegar desde Zip" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Verificar que el zip existe
if (-not (Test-Path $ZipFile)) {
  throw "ERROR: No encontré el archivo zip: $ZipFile"
}

Write-Host "[1/5] Preparar..." -ForegroundColor Yellow
Write-Host "  Zip file: $ZipFile" -ForegroundColor Cyan
Write-Host "  Destino: $olamRoot" -ForegroundColor Cyan

# Limpiar carpeta temporal de previas extracciones
if (Test-Path $tempExtract) {
  Remove-Item $tempExtract -Recurse -Force
  Write-Host "  Limpieza previa: OK" -ForegroundColor Green
}

Write-Host ""
Write-Host "[2/5] Extraer zip..." -ForegroundColor Yellow

# Expandir zip a carpeta temporal
Expand-Archive -Path $ZipFile -DestinationPath $tempExtract -Force
Write-Host "  ✓ Extraído a: $tempExtract" -ForegroundColor Green

# Copiar contenido a $olamRoot (sobrescribir)
# Nota: backend y frontend contendrán node_modules viejos — los eliminaremos
Write-Host ""
Write-Host "[3/5] Actualizar código..." -ForegroundColor Yellow

# Copiar backend (excluir node_modules)
Write-Host "  Backend..." -ForegroundColor Cyan
Remove-Item "$backendPath\node_modules" -Recurse -ErrorAction SilentlyContinue
Copy-Item "$tempExtract\backend\*" -Destination $backendPath -Recurse -Force
Write-Host "    ✓ Backend actualizado" -ForegroundColor Green

# Copiar frontend (excluir node_modules y dist)
Write-Host "  Frontend..." -ForegroundColor Cyan
Remove-Item "$frontendPath\node_modules" -Recurse -ErrorAction SilentlyContinue
Remove-Item "$frontendPath\dist" -Recurse -ErrorAction SilentlyContinue
Copy-Item "$tempExtract\frontend\*" -Destination $frontendPath -Recurse -Force
Write-Host "    ✓ Frontend actualizado" -ForegroundColor Green

# Copiar scripts y docs (por si cambiaron)
Write-Host "  Docs y scripts..." -ForegroundColor Cyan
Copy-Item "$tempExtract\scripts\*" -Destination "$olamRoot\scripts" -Recurse -Force
Copy-Item "$tempExtract\docs\*" -Destination "$olamRoot\docs" -Recurse -Force
Write-Host "    ✓ OK" -ForegroundColor Green

Write-Host ""
Write-Host "[4/5] npm install..." -ForegroundColor Yellow

# Backend
Write-Host "  Backend..." -ForegroundColor Cyan
cd $backendPath
npm install --omit=dev 2>&1 | Out-Null
Write-Host "    ✓ OK" -ForegroundColor Green

# Frontend
Write-Host "  Frontend..." -ForegroundColor Cyan
cd $frontendPath
npm install --omit=dev 2>&1 | Out-Null
Write-Host "    ✓ OK" -ForegroundColor Green

Write-Host ""
Write-Host "[5/5] Reiniciar servicios..." -ForegroundColor Yellow

Write-Host "  Matando procesos node..." -ForegroundColor Cyan
Get-Process node -ErrorAction SilentlyContinue | Stop-Process -Force
Start-Sleep -Seconds 2
Write-Host "    ✓ OK" -ForegroundColor Green

# Limpiar temp
Write-Host "  Limpieza..." -ForegroundColor Cyan
Remove-Item $tempExtract -Recurse -Force
Write-Host "    ✓ OK" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "✓ DEPLOYMENT COMPLETADO" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Próximos pasos:" -ForegroundColor Cyan
Write-Host ""
Write-Host "Terminal 1 — Backend (puerto 3000):" -ForegroundColor Cyan
Write-Host "  cd $backendPath" -ForegroundColor Gray
Write-Host "  npm run dev" -ForegroundColor Gray
Write-Host ""
Write-Host "Terminal 2 — Frontend (puerto 5173):" -ForegroundColor Cyan
Write-Host "  cd $frontendPath" -ForegroundColor Gray
Write-Host "  npm run dev" -ForegroundColor Gray
Write-Host ""
Write-Host "Dashboard: http://localhost:5173" -ForegroundColor Green
Write-Host ""
